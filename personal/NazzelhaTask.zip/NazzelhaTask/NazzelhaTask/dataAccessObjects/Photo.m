//
//  Photo.m
//  NazzelhaTask
//
//  Created by Mohammed Gamal on 11/5/14.
//  Copyright (c) 2014 Mohammed Gamal. All rights reserved.
//

#import "Photo.h"

@implementation Photo

@end
